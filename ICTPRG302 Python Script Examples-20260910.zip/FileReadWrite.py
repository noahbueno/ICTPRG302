#!/usr/bin/python3

"""
AUTHOR: Hsu Win
PURPOSE: Script with examples of using Python in class to:
 - using the datetime library
 - file reading and writing

VERSION  | DATE     | WHO | COMMENTS
------------------------------------------------------------------------
0.1      | 18/03/25 | HW  | Initial version developed by Hsu Win
0.2      | 11/08/26 | RJ  | Updated to add shebang and header,
                            change structure to match coding standards,
                            added function definitions,
                            and added main function
"""

# using datetime library
import datetime

# using the errno library
import errno

# variable declarations
# date and time variables
l_date = datetime.date(2025,3,20)
l_time = datetime.time(11,20,20)
l_datetime = datetime.datetime(2025,3,20,11,20,20)
now = datetime.datetime.today()
date_withouthyphen = datetime.datetime.strftime(now,"%Y%m%d%H%M%S")
# file variables

def date_time_examples():
    print(l_date)
    print(l_time)
    print(l_datetime)
    print("today (UTC format) : ", now)
    print("today date : ", date_withouthyphen)

def read_and_write_to_files_example():
    try:
        # change file directory & reading the text file
        f = open("Test Files/TestFile.txt")
        text=f.read()
        f.close()
        print(text)

        # reading the file (without requiring to close it)
        with open("Test Files/TestFile.txt") as fobj:
            bio = fobj.read()
        print(bio)

        # writing (overwritting) the file (without requireing to close it)
        oceans = ["Pacific1", "Atlantic1"]
        with open("Test Files/oceans.txt","w") as f:
            for oc in oceans:
                f.write(oc)
                f.write("\n")
                
        # appending (without overwritting) the file (without requireing to close it)
        with open("Test Files/oceans.txt","a") as f:
            print(23*"=", file=f)
            print("These are the 2 oceans.", file=f)
        
        # let the user know the program is finished
        print("Program ran without an error. Files have been updated.")

    except OSError as e:
        if e.errno == errno.ENOENT:
            print("ERROR: No such file or directory")
    
    except FileNotFoundError:
        print("ERROR: File does not exist.")
    
    except IOError:
        print("ERROR: File is not accessible.")        

def main():
    # run the functions
    date_time_examples()
    read_and_write_to_files_example()

if __name__ == '__main__':
    main()