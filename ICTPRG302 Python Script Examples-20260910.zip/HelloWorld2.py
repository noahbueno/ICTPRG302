"""
AUTHOR: Hsu Win
PURPOSE: Second script with examples demonstrating things learnt using Python in class.

VERSION  | DATE     | WHO | COMMENTS
------------------------------------------------------------------------
0.1      | 18/03/25 | HW  | Initial version developed by Hsu Win
0.2      | 11/08/26 | RJ  | Updated header to use docstring conventions
                            
LIST WHAT HAS BEEN LEARNT IN THIS PROGRAM:
 - function with keywords - giving the default to the parameter
 - class with __init__
 - logging
 - try-except-else-finally
 - how to open/read the text/data from file (rb command)
 - how to open/read the file "with" keyword
 - change file directory accordingly
"""

# how to use function
def cm(feet = 0, inches = 0):
    """Coverts a length from feet and inches to centimeters."""
    inches_to_cm = inches * 2.54
    feet_to_cm = feet * 12* 2.54
    return inches_to_cm + feet_to_cm

tmp = cm(feet = 5)
print("inches = ", tmp)

# function with keywords parameter and required parameter
def g(y, x=0):
    return x-y
tmp = g(5)
print(tmp)
tmp = g(5, x=1)
print(tmp)
tmp = g(5,1)
print(tmp)

# class and its fields/ attributes/ property
class User:
    pass
user1 = User()
user1.first_name = "Dave"
user1.last_name = "Bowman"
print(user1.first_name)
print(user1.last_name)

user2 = User()
user2.first_name = "Frank"
user2.last_name = "Poole"

user1.age = 20
user2.favorite_book = "Python book"

# introduce __init__ which used as a constructor to initialize an object's attributes when a class instance/object is created/initialized.
import datetime # import datetime library for datetime calculation
class Student:
    """A member of FriendFace. For now we are only storing"""
    def __init__(self, full_name, birthday):
        self.name=full_name
        self.birthday=birthday
        
    def age(self):
        """Return the age of the student in years."""
        today = datetime.date(2025, 3, 20)
        yyyy = int(self.birthday[0:4])
        mm = int(self.birthday[4:6])
        dd = int(self.birthday[6:8])
        dob = datetime.date(yyyy,mm,dd)
        age_in_days = (today-dob).days
        age_in_years = age_in_days / 365
        return int(age_in_years)
        
student1 = Student("Dave Bowman", "19710315")
print(student1.name)
print(student1.age())

# how to use "for loop"
for i in range(5):
    print(i)
    
# Create logger using logging library
import logging
import time
logging.basicConfig(filename="loginfo.log", level = logging.DEBUG) 
logger=logging.getLogger()
# read the file and throw exception if it is not found
def read_file(path):
    """Return the contents of the file at 'path' and measure time required."""
    start_time = time.time()
    try:
        f=open(path, mode="rb")
        data = f.read ()
        return data
    except FileNotFoundError as err:
        logger.error(err)
        raise
    else:
        f.close()
    finally:
        stop_time = time.time()
        dt = stop_time - start_time
        logger.info("Time required for {file} = {time}".format(file=path, time=dt))
    
data=read_file("HelloWorld.py")
print("read : ", data)

# how to import other Python class file and call its function
# Note that you make sure to create "main" method and other functions in imported Python file. 
# If there is no "main" method, all lines (i.e., no Indentation program lines) will be executed
# import HelloWorld
# print(HelloWorld.ping())

# import only specific function

# read the file
with open("HelloWorld.py") as f:
    text=f.read()
    
# write the file
oceans = ["test1","test2","test3"]
with open("Test Files/Test.txt", "w") as f: # if the file does not exist, will create with that name. if it exist, will overwrite it
    for o in oceans:
        f.write(o)# will write with no next line


with open("Test Files/Test.txt", "w") as f: # if the file does not exist, will create with that name. if it exist, will overwrite it
    for o in oceans:
        print(o,file=f) # will write with next line
      
oceans = ["aaa1","aaa2","aaa3"]
# append the file
with open("Test Files/Test.txt", "a") as f: # if the file does not exist, will create with that name. if it exist, will append it
    for o in oceans:
        f.write(o)# will write with no next line
        
# opening the file that does not exist
with open("x_files.txt") as xf:
    the_truth = xf.read()
    
print(the_truth)