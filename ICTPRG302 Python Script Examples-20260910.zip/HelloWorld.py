"""
AUTHOR: Hsu Win
PURPOSE: Script with examples demonstrating things learnt using Python in class.

VERSION  | DATE     | WHO | COMMENTS
------------------------------------------------------------------------
0.1      | 17/03/25 | HW  | Initial version developed by Hsu Win
0.2      | 11/08/26 | RJ  | Updated header to use docstring conventions
                            Added example function without any parameters
                             and relevant import

LIST WHAT HAS BEEN LEARNT IN THIS PROGRAM:
 - data type - number : float, integer, complex number data type
 - string data type
 - how to give the variable name (either using "_" or camel case)
 - list, combine list, concatinate, reverse
 - that list can keep different data types (integer, float, boolean, string)
 - tuple, difference between tuple and list
 - "for" loop to print out all numbers in list or tuple
 - how to declar the library (e.g., import sys) and use it (e.g., sys.getsizeof)
 - how long it takes to run list and tuple for same data
 - how to retrieve the data from the tuple
 -- (1) by using the index
 -- (2) by assigning variables
 - set()
 - dictionary
 - condition checking (if else)
 - try catch exception
 - get function for dictionary
 - to retrieve all values of dictionary based on all keys of dictionary via "for" loop
 - to retreive all keys and values from dictionary (items() function)
 - how to use operators (i.e., ==, !=, <, >)
 - boolean (i.e., 0 or 1) (i.e., True or False)
 - Arithmetic (+, -, *, /, %)
 - datatype conversion
 - getting Input from user
 - checking Condition (i.e., if elif else)
 - Class
 - Function (with keywords, without keywords (i.e., required))
"""

# printing "Hello, Hsu"
print("Hello, Hsu")

# different datatypes (i.e., integer, float, complex, String)
student_count=1000 # integer
rating=4.99 # float
complextext=2-6j # complex
nameString="Hsu" # string
print(student_count)
print(rating)
print(complextext)
print(nameString)

# print(dir(student_count)) #  dir() function returns all properties and methods of the specified object

# how to use long string
movie_quote = """One of my favorite lines from the Godfather is:
..."I'm going to make him an offer he can't refuse."
...Do you know who said this?""" #  string - how we use next line, double quote, single quote
print(movie_quote)

# how to use list
example = list()
example = []
primes = [2,3,5,7,11,13]
print(primes)
primes.append(17) #  appending list
primes.append(19)
print(primes)
print(primes[-2])
print(primes[0:3]) # slicing
example = [128, True, "Alpha", 1.732, [64,False]] #  list can keep different datatypes
print(example)

# combine two lists
numbers = [1,2,3]
letters = ['a','b','c']
num_letters = numbers + letters
print(num_letters)

# reverse the list
numbers.reverse() 
print(numbers)

# list example
prime_numbers=[2,3,5,7,11,13,17]

# tuple example
perfect_squares = (1,4,9,16,25,36)

# Display lengths
print("#  Primes =", len(prime_numbers))
print("#  Squares = ", len (perfect_squares))

# For loop to print out the numbers in the list and tuple
for p in prime_numbers:
 print("Prime = ",p)
 
for n in perfect_squares:
    print("Number =", n)
    
# how to import (sys) library and use
import sys # declar the library
list_eg= [1,2,3,"a","b","c",True, 3.14159]
tuple_eg = (1,2,3,"a","b","c",True, 3.14159)
print("list size = ", sys.getsizeof(list_eg)) # get the size of list by using sys library
print("tuple size =", sys.getsizeof(tuple_eg)) # get the size of tuple by using sys library

# how to import (timeit) library and use
import timeit
list_test = timeit.timeit(stmt="[1,2,3,45]", number=10000000) # check how long it takes to run list for 1 mil
tuple_test = timeit.timeit(stmt="(1,2,3,45)", number=10000000) #  check how long it takes to run tuple for 1 mil
print("List time: ",list_test)
print("Tuple time: ", tuple_test)

# using the tuple to store record/s
# (age, country, knows_python)
survey = (27, "Vietnam", True) 
age = survey [0] # to retrieve value/s in tuple, (similar to list) you can use index 
country = survey[1]
knows_python = survey[2]
print ("Age = ", age)
print ("Country = ", country)
print ("Knows Python = ", knows_python)

survey2 = (21, "Switzerland", False)
age,country,knows_python=survey2 # to retrieve value/s in tuple, you can assign to the speicifc variable/s 
print ("Age = ", age)
print ("Country = ", country)
print ("Knows Python = ", knows_python)

# example for set and adding element into it
exampleSet = set()
exampleSet.add(42)
exampleSet.add(False)
exampleSet.add(3.14159)
print(exampleSet)
exampleSet.add(42)
print(exampleSet)
exampleSet.remove(42) # remove the element
print(exampleSet)
# exampleSet.remove(50)
exampleSet.discard(50)

example2 = set([28, True, 2.71828, "Helium"])
print(len(example2))
example2.clear()
print(len(example2))

print(type(example2))

# union, intersect for set
odds = set([1,3,5,7])
evens = set([2,4,6,8,10])
primes = set ([2,3,5,7])
composites = set ([4,6,8,9,10])
print(odds.union(evens))
print(odds.intersection(primes))
print(15 in odds) # check if the value/element value in the set
print(15 not in odds) # check if the value/elemenent not in the set

# dictionary : key, value mapping
post2 = dict(message="SS Cotopaxi", language = "English")
print(post2)
print(post2["message"])
# print(post2["location"])

# if else - condition
if "location" in post2:
    print(post2["location"])
else:
    print("There is no location key.")

# try catch - exception
# if the key (i.e.post2["location"]) is found, print value
# if not, throw exception 
try:
    print(post2["location"])
except KeyError:
    print("There is no location key.")
    
#  If key (i.e.post2["location"]) is found, return value. If not, return "None"
loc = post2.get('location',None) 
print(loc)

# get all values based on all keys (i.e., keys function) in dictionary
for key in post2.keys():
    value=post2[key]
    print (key, "=", value)
   
# get all keys and values via items function 
for key,value in post2.items():
    print(key, "=", value)
 
# learning about boolean (0 or 1) (True or False) via operator (i.e., ==, != , < , >)  
a = 2
b = 5
print(a == b)
print(a != b)
print(a>b)
print(a<b)
print(a>=b)
print(b<=b)
print(bool(28))

# Arithmetic ( + , - , * , /, %)
x = 20
y = 10
z = x + y # adding
r = x - y # subtracting
l = x * y # multiplication
m = x/y   # division
n = x%y   # reminder
print (z)
print (r)
print (l)
print (m)
print (n)

# datatype coversion
print(str(27))
print(float(27))

# getting the input from user
inputData = input("Please enter a test string: ")
if len(inputData) < 6: # check condition
    print ("Your data length is less than 6")
elif len(inputData) > 6:
    print ("Your data length is greater 6")
else:
    print ("Your data is equal to 6")

# How to use Class
class User:
    pass

user1 = User() # create the object of User class
user1.first_name="Dave" # assign the fields/attribute/property of class

print(user1.first_name)

# how to write/use function (without any parameters)
def ping():
    return "Ping!"

returnValue = ping() #  call the function
print(returnValue)

# how to import (math & datetime) libraries
import math

# function with one parameter    
def volume(r):
    """Returns the volume of a sphere with radius r."""
    v = (4.0/3.0) * math.pi * r**3
    return v

# running the function above
tmp = volume(2)
print ("volume =", tmp)

# function with two parameters/ arguments
def traingle_area(b,h):
    """Returns the area of a triangle with base b and height h."""
    return 0.5*b*h

# running the function above
tmp = traingle_area(3,6)
print("triangle area = ", tmp)

# function with keywords - giving the default to the parameter
def cm(feet = 0, inches = 0):
    """Coverts a length from feet and inches to centimeters."""
    inches_to_cm = inches * 2.54
    feet_to_cm = feet * 12* 2.54
    return inches_to_cm + feet_to_cm

# running the function above
tmp = cm(feet = 5)
print("inches = ", tmp)